#include <iostream>
#include <string>

std::string hello(std::string s)
{
	return "hello world " + s;
}